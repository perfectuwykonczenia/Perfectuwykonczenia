Wrzuć tu swoje zdjęcia realizacji w formacie JPG/PNG.
Następnie dodaj odpowiednie <img> linie w sekcji Galeria w index.html.
